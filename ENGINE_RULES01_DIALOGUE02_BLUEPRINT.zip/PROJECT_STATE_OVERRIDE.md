## Current Override — ENGINE-RULES-01 / DIALOGUE-02

- Status: `GPT_BLUEPRINT_COMPLETE_CODEX_READY`
- Current work: `ENGINE_RULES01_DIALOGUE02`
- Collaboration: `GPT_PLANS_CODEX_IMPLEMENTS`
- Implementation branch: `codex/engine-rules01-dialogue02`
- Goal: `ENGINE_ENFORCED_PRODUCTION_RULES`
- Key rule: bad drafts may exist, but any BLOCKER prevents final selection.
- Mandatory negative fixture: `好。先碰你。`
- Required gate: `docs/CURRENT_ROUTE_GATE_V7.md`
- Required charter: `docs/ENGINE_ENFORCED_PRODUCTION_RULES_V1.md`
- Required work package: `docs/work-packages/ENGINE-RULES-01_DIALOGUE-02.md`
- DIALOGUE-01 is historical evidence and must be re-evaluated, not silently trusted.
- GitHub remote is the highest team authority.
- Do not start image, video, Provider, Canon, next chapter or interactive game.
