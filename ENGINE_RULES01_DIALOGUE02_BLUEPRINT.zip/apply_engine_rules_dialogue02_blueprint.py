from pathlib import Path
import shutil, re

bundle = Path(__file__).resolve().parent
repo = Path.cwd()

if not (repo / "PROJECT_STATE.md").exists():
    raise SystemExit("請在 ai-novel-engine Repository 根目錄執行。")

copy_paths = [
    "docs/ENGINE_ENFORCED_PRODUCTION_RULES_V1.md",
    "docs/CURRENT_ROUTE_GATE_V7.md",
    "docs/work-packages/ENGINE-RULES-01_DIALOGUE-02.md",
    "docs/handoffs/ENGINE_RULES01_CODEX_HANDOFF.md",
    ".codex/engine_rules01_controller.md",
]

for rel in copy_paths:
    src = bundle / rel
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and dst.read_bytes() != src.read_bytes():
        raise SystemExit(f"目标已存在且不同，请人工检查：{rel}")
    shutil.copy2(src, dst)

state_path = repo / "PROJECT_STATE.md"
state = state_path.read_text(encoding="utf-8")
pattern = r"\n## Current Override — .*?(?=\n## |\Z)"
state = re.sub(pattern, "\n", state, count=1, flags=re.S)

override = (bundle / "PROJECT_STATE_OVERRIDE.md").read_text(encoding="utf-8").strip()
lines = state.splitlines()
insert_at = 1 if lines else 0
lines[insert_at:insert_at] = ["", override, ""]
state_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")

print("ENGINE-RULES-01 / DIALOGUE-02 蓝图已套用。")
print("必须以 Kotlin/SQLite/CLI/tests 完成；Markdown-only 不算完成。")
